# 📱 Installation Guide - Task Progress Tracker

## Quick Start (3 Steps!)

### For Friends (Easiest Method)

**On Phone (Android):**
1. Open Chrome browser
2. Visit: `https://your-username.github.io/task-tracker-pwa`
3. Tap "Install" button at bottom → Done! 🎉

**On Phone (iOS/iPhone):**
1. Open Safari browser
2. Visit: `https://your-username.github.io/task-tracker-pwa`
3. Tap Share button (box with arrow) → "Add to Home Screen" → Done! 🎉

**On Computer:**
1. Open Chrome/Edge browser
2. Visit: `https://your-username.github.io/task-tracker-pwa`
3. Click install icon in address bar → Done! 🎉

---

## 🌐 Method 1: Use GitHub Pages (Free Hosting)

This is the **BEST** method for sharing with friends!

### Step 1: Upload to GitHub

```bash
# 1. Create a new repository on GitHub.com
#    - Name it: task-tracker-pwa
#    - Make it Public
#    - Don't initialize with README

# 2. On your computer, navigate to the folder with the app files
cd path/to/task-tracker-pwa

# 3. Initialize git and upload
git init
git add .
git commit -m "Initial commit - Task Tracker PWA"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/task-tracker-pwa.git
git push -u origin main
```

### Step 2: Enable GitHub Pages

1. Go to your repository on GitHub.com
2. Click **Settings** tab
3. Scroll to **Pages** section (left sidebar)
4. Under "Source", select **main** branch
5. Click **Save**
6. Wait 1-2 minutes

### Step 3: Share the Link!

Your app is now live at:
```
https://YOUR-USERNAME.github.io/task-tracker-pwa
```

**Share this link with friends** and they can install it as an app!

---

## 💻 Method 2: Run Locally (For Testing)

### Option A: Simple HTTP Server (Python)

```bash
# Navigate to the app folder
cd task-tracker-pwa

# Start server (Python 3)
python -m http.server 8000

# Or if you have Python 2
python -m SimpleHTTPServer 8000

# Open browser and visit:
# http://localhost:8000
```

### Option B: Node.js Server

```bash
# Install http-server globally (one time)
npm install -g http-server

# Navigate to app folder
cd task-tracker-pwa

# Start server
http-server -p 8000

# Open browser and visit:
# http://localhost:8000
```

### Option C: VS Code Live Server

1. Install "Live Server" extension in VS Code
2. Open the `task-tracker-pwa` folder
3. Right-click `index.html` → "Open with Live Server"
4. Browser opens automatically!

---

## 📤 Method 3: Deploy to Other Platforms

### Netlify (Free, Easy)

1. Go to [netlify.com](https://netlify.com)
2. Sign up (free)
3. Drag the `task-tracker-pwa` folder onto the upload zone
4. Get instant URL: `https://random-name.netlify.app`
5. Share with friends!

### Vercel (Free, Fast)

```bash
# Install Vercel CLI
npm install -g vercel

# Navigate to app folder
cd task-tracker-pwa

# Deploy
vercel

# Follow prompts, get instant URL!
```

---

## 🔧 Troubleshooting

### "Install button doesn't appear"

**Solution:**
- Must use HTTPS (not HTTP)
- GitHub Pages automatically uses HTTPS ✅
- Local testing won't show install button (that's normal)

### "App doesn't work offline"

**Solution:**
- Service worker only works on HTTPS
- GitHub Pages enables this automatically
- Visit the app at least once while online first

### "Can't add to home screen on iPhone"

**Solution:**
- Must use **Safari** (not Chrome)
- Tap Share button → scroll down → "Add to Home Screen"
- Other browsers on iOS don't support PWA install

### "Icons don't show up"

**Solution:**
- Make sure `icon-192.png` and `icon-512.png` are in the same folder
- Clear browser cache
- Uninstall and reinstall the app

---

## 📱 Sharing Best Practices

### What to send friends:

**Text Message:**
```
Hey! I made a productivity app and I'd love for you to try it!

📱 Install it here: https://your-username.github.io/task-tracker-pwa

On phone: Visit link → Tap "Install" at bottom
On iPhone: Visit link → Share → Add to Home Screen

It has Focus Mode, AI coaching, and helps beat procrastination!
```

**Social Media Post:**
```
🚀 Just launched my task tracker app!

✅ Focus Mode - work on ONE task at a time
🔗 Task Dependencies - logical workflows
⏰ Time Blocking - see if you actually have time
🔥 Procrastination AI - get coached on what you avoid

📱 Install: https://your-username.github.io/task-tracker-pwa

Free, no sign-up, works offline! Made with ❤️
```

---

## 🎉 Success!

Once installed, your friends can:
- ✅ Use it like a native app
- ✅ Access from home screen
- ✅ Work offline
- ✅ Get notifications
- ✅ Share it with others!

---

## 💡 Tips

1. **Update the app**: Just git push changes to GitHub, the link stays the same!
2. **Custom domain**: GitHub Pages supports custom domains (e.g., tasktracker.com)
3. **Analytics**: Add Google Analytics to track usage (optional)
4. **Feedback**: Create a feedback form or use GitHub Issues

---

**Questions?** Open an issue on GitHub!

**Made with ❤️ by Navsurya**
