#!/bin/bash
# Automatic Update Script for GitHub
# Run this from your repo folder

echo "🚀 Task Tracker - GitHub Update Script"
echo "======================================"
echo ""

# Check if we're in a git repo
if [ ! -d ".git" ]; then
    echo "❌ Error: Not in a git repository!"
    echo "Please run this script from your repo folder."
    exit 1
fi

echo "📁 Current directory: $(pwd)"
echo ""

# Backup current version
echo "💾 Creating backup branch..."
BACKUP_BRANCH="backup-$(date +%Y%m%d-%H%M%S)"
git branch $BACKUP_BRANCH
echo "✅ Backup created: $BACKUP_BRANCH"
echo ""

# Copy new files (you need to place the 5 files in same folder as this script)
echo "📥 Updating files..."

if [ -f "index.html" ]; then
    echo "  ✅ index.html found"
else
    echo "  ⚠️  index.html not found - place it in repo folder"
fi

if [ -f "manifest.json" ]; then
    echo "  ✅ manifest.json found"
else
    echo "  ⚠️  manifest.json not found"
fi

if [ -f "service-worker.js" ]; then
    echo "  ✅ service-worker.js found"
else
    echo "  ⚠️  service-worker.js not found"
fi

echo ""
echo "📝 Git status:"
git status --short
echo ""

# Add files
echo "➕ Adding updated files..."
git add index.html manifest.json service-worker.js icon-192.png icon-512.png
echo ""

# Commit
echo "💬 Creating commit..."
git commit -m "Update: Dark Mode, Feature Menu, Free AI, Fixed PWA install

New Features:
- 🌓 Dark Mode with toggle
- ✨ Feature Menu (15+ features)
- 🤖 Free AI feedback (HuggingFace)
- 📱 Fixed PWA installation

Fixes:
- Service worker paths for GitHub Pages
- Manifest configuration
- AI integration (no API key needed)
"

echo ""
echo "🚀 Pushing to GitHub..."
git push

echo ""
echo "✅ Update Complete!"
echo ""
echo "📋 Next Steps:"
echo "  1. Wait 2-3 minutes for GitHub Pages to rebuild"
echo "  2. Visit your URL"
echo "  3. Hard refresh: Ctrl+Shift+R (or Cmd+Shift+R on Mac)"
echo "  4. Check for new features:"
echo "     - Dark mode toggle (top-right)"
echo "     - Feature menu button (purple, '15' badge)"
echo "     - AI feedback (scroll down)"
echo ""
echo "🔙 To rollback: git checkout $BACKUP_BRANCH && git push -f"
echo ""
echo "🎉 Done! Your app is updated!"
